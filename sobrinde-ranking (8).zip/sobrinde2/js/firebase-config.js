var firebaseConfig = {
  apiKey: "AIzaSyAfXM5M7RQxOF_Tp78orlS5zwC9tVFoHD0",
  authDomain: "rankinkg-semanal-so-brinde.firebaseapp.com",
  projectId: "rankinkg-semanal-so-brinde",
  storageBucket: "rankinkg-semanal-so-brinde.firebasestorage.app",
  messagingSenderId: "633825478784",
  appId: "1:633825478784:web:581b5e2c3fef4f7ae17e65"
};
firebase.initializeApp(firebaseConfig);
var SB = {
  db:   firebase.firestore(),
  auth: firebase.auth(),
  admins: ["sidinei@sobrinde.com.br","edson@sobrinde.com.br","emerson@sobrinde.com.br"],
  isAdmin: function(email){ return SB.admins.indexOf(email) !== -1; }
};
window.SBFirebase = SB;
