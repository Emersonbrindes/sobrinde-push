var SB=window.SBFirebase,db=SB.db,auth=SB.auth;
var userAtual=null,isAdmin=false,representantes=[],dadosMes=null,mesAtual='';
var MES_INICIAL='2026-04';

function R$(v){return 'R$ '+parseFloat(v||0).toLocaleString('pt-BR',{minimumFractionDigits:2,maximumFractionDigits:2});}
function PCT(v){return parseFloat(v||0).toLocaleString('pt-BR',{minimumFractionDigits:1,maximumFractionDigits:1})+'%';}
function ddmm(d){if(!d)return '?';var p=d.split('-');return p[2]+'/'+p[1];}
function nomeMes(ym){var m=['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'];var p=ym.split('-');return m[parseInt(p[1])-1]+'/'+p[0];}
function iniciais(n){return n.split(' ').slice(0,2).map(function(x){return x[0];}).join('').toUpperCase();}
function diasDoMes(ym){var p=ym.split('-');return new Date(parseInt(p[0]),parseInt(p[1]),0).getDate();}
function pad(n){return String(n).padStart(2,'0');}
function diaSemNome(ano,mes,dia){return ['Dom','Seg','Ter','Qua','Qui','Sex','Sáb'][new Date(ano,mes-1,dia).getDay()];}

// ── FORMATAÇÃO CONTÁBIL ───────────────────────
function parseContabil(str){
  if(!str)return 0;
  str=str.trim();
  var clean=str.replace(/\./g,'').replace(',','.');
  return parseFloat(clean)||0;
}
function toContabil(num){
  if(!num&&num!==0)return '';
  return parseFloat(num).toLocaleString('pt-BR',{minimumFractionDigits:2,maximumFractionDigits:2});
}
function formatarContabil(input){
  input._raw=parseContabil(input.value);
}
function finalizarContabil(input){
  var num=parseContabil(input.value);
  input._raw=num;
  input.value=num>0?toContabil(num):'';
}
function valorContabil(input){
  return parseContabil(input.value);
}
function initContabil(input,valor){
  var num=parseFloat(valor)||0;
  input._raw=num;
  input.value=num>0?toContabil(num):'';
}

// ── INIT ──────────────────────────────────────
auth.onAuthStateChanged(function(user){
  if(!user){location.href='index.html';return;}
  userAtual=user; isAdmin=SB.isAdmin(user.email);
  document.getElementById('sbEmail').textContent=user.email;
  document.getElementById('sbRole').textContent=isAdmin?'Administrador':'Representante';
  if(isAdmin) document.querySelectorAll('.admin-only').forEach(function(el){el.style.display='';});
  if(!isAdmin){document.body.classList.add('hide-meta');}else{document.body.classList.remove('hide-meta');}

  var agora=new Date();
  var dataHora=agora.toLocaleString('pt-BR',{timeZone:'America/Sao_Paulo'});
  var perfil=isAdmin?'Administrador':'Representante';

  function enviarEmailLogin(lat,lng,gmaps){
    if(typeof emailjs==='undefined'){console.log('EmailJS não carregado');return;}
    emailjs.send('service_3iq9pth','template_5pel3ns',{
      representante:user.email,user_login:user.email,user_role:perfil,
      login_time:dataHora,
      location:lat?lat.toFixed(4)+', '+lng.toFixed(4):'Via IP (GPS negado)',
      gmaps:gmaps||'Não disponível',
      user_agent:navigator.userAgent.substring(0,120)
    }).then(function(){console.log('Email enviado!');})
      .catch(function(e){console.log('EmailJS erro:',e);});
  }

  var log={email:user.email,timestamp:agora.toISOString(),perfil:perfil,userAgent:navigator.userAgent};

  function salvarEEnviar(lat,lng,gmaps){
    if(lat){log.lat=lat;log.lng=lng;log.gmaps=gmaps;}
    db.collection('logs_acesso').add(log).catch(function(){});
    enviarEmailLogin(lat,lng,gmaps);
  }

  if(navigator.geolocation){
    navigator.geolocation.getCurrentPosition(
      function(p){
        var gmaps='https://maps.google.com?q='+p.coords.latitude+','+p.coords.longitude;
        salvarEEnviar(p.coords.latitude,p.coords.longitude,gmaps);
      },
      function(err){
        fetch('https://ipapi.co/json/')
          .then(function(r){return r.json();})
          .then(function(data){
            if(data.latitude&&data.longitude){
              var gmaps='https://maps.google.com?q='+data.latitude+','+data.longitude;
              salvarEEnviar(data.latitude,data.longitude,gmaps);
            }else{salvarEEnviar(null,null,null);}
          }).catch(function(){salvarEEnviar(null,null,null);});
      },{timeout:8000,enableHighAccuracy:false,maximumAge:60000});
  }else{salvarEEnviar(null,null,null);}

  carregarRepresentantes().then(popularTodosSelects).then(carregarDados).then(esconderLoading);
});

function esconderLoading(){
  var el=document.getElementById('loading');
  el.style.opacity='0';el.style.transition='opacity .4s';
  setTimeout(function(){el.style.display='none';},400);
}

function carregarRepresentantes(){
  return db.collection('config').doc('representantes').get().then(function(doc){
    if(doc.exists&&doc.data().lista&&doc.data().lista.length>0){representantes=doc.data().lista;}
    else{representantes=[];for(var i=1;i<=13;i++)representantes.push({id:'rep'+pad(i),nome:'Representante '+i,email:''});}
  });
}

function popularTodosSelects(){
  return db.collection('periodos').get().then(function(snap){
    var agora=new Date();
    var hoje=agora.getFullYear()+'-'+pad(agora.getMonth()+1);
    var meses=new Set([hoje]);
    snap.forEach(function(d){if(d.id>=MES_INICIAL)meses.add(d.id);});
    for(var i=1;i<=3;i++){var dd=new Date(agora.getFullYear(),agora.getMonth()+i,1);var ym=dd.getFullYear()+'-'+pad(dd.getMonth()+1);if(ym>=MES_INICIAL)meses.add(ym);}
    var lista=Array.from(meses).filter(function(m){return m>=MES_INICIAL;}).sort().reverse();
    ['mesSelect','mesVendas','mesMestasSelect','cfgMes','mesMinhasVendas'].forEach(function(id){popularSelect(id,lista,hoje);});
    mesAtual=hoje;
  });
}

function popularSelect(id,lista,sel){
  var s=document.getElementById(id);if(!s)return;
  s.innerHTML='';
  lista.forEach(function(m){var o=document.createElement('option');o.value=m;o.textContent=nomeMes(m);s.appendChild(o);});
  if(sel)s.value=sel;
}

function carregarDados(){
  dadosMes=null;
  mesAtual=document.getElementById('mesSelect').value;
  return Promise.all([db.collection('periodos').doc(mesAtual).get(),db.collection('vendas').doc(mesAtual).get()])
    .then(function(r){
      var vendasRaw=r[1].exists?r[1].data():{};
      var vendasFiltradas={};
      var prefixo=mesAtual+'-';
      Object.keys(vendasRaw).forEach(function(k){if(k.indexOf(prefixo)===0)vendasFiltradas[k]=vendasRaw[k];});
      dadosMes={periodo:r[0].exists?r[0].data():null,vendas:vendasFiltradas};
      renderRanking();
    });
}

// ── NAVEGAÇÃO ─────────────────────────────────
function irPara(pag){
  document.querySelectorAll('.page').forEach(function(p){p.classList.remove('ativa');});
  document.querySelectorAll('.nav-btn').forEach(function(b){b.classList.remove('ativo');});
  document.getElementById('page-'+pag).classList.add('ativa');
  document.querySelector('[data-page="'+pag+'"]').classList.add('ativo');
  if(pag==='vendas')sincVendas();
  if(pag==='metas')carregarMetasForm();
  if(pag==='periodo')carregarPeriodoForm();
  if(pag==='representantes')renderRepsLista();
  if(pag==='minhas-vendas')carregarMinhasVendas();
}

// ── RANKING ───────────────────────────────────
function renderRanking(){
  if(!dadosMes||!dadosMes.periodo){
    document.getElementById('campeaoArea').innerHTML='';
    document.getElementById('rankingTabela').innerHTML='<div class="empty-state"><div class="empty-icon">📊</div><div class="empty-title">Período não configurado</div></div>';
    document.getElementById('periodoInfo').textContent=nomeMes(mesAtual);
    document.getElementById('rankingLegenda').textContent='—';return;
  }
  var semanas=dadosMes.periodo.semanas||[],metas=dadosMes.periodo.metas||{},vendas=dadosMes.vendas||{};
  var semsComDados={};
  Object.values(vendas).forEach(function(d){if(d.semana)semsComDados[parseInt(d.semana)]=true;});
  document.getElementById('periodoInfo').textContent=nomeMes(mesAtual)+' · '+semanas.length+' semana'+(semanas.length!==1?'s':'');
  var res=representantes.map(function(rep){
    var meta=parseFloat(metas[rep.id]||0);
    var pcts=semanas.map(function(_,idx){
      var sem=idx+1,tot=0;
      Object.values(vendas).forEach(function(d){if(parseInt(d.semana)===sem&&d[rep.id])tot+=parseFloat(d[rep.id])||0;});
      return{p:meta>0?(tot/meta)*100:0,tem:!!semsComDados[sem]};
    });
    var comDados=pcts.filter(function(s){return s.tem;});
    var media=comDados.length>0?comDados.reduce(function(a,b){return a+b.p;},0)/comDados.length:0;
    return{rep:rep,meta:meta,pcts:pcts,media:media,n:comDados.length};
  });
  res.sort(function(a,b){return b.media-a.media;});
  document.getElementById('rankingLegenda').textContent=semanas.length+' semanas · média lançadas';
  renderCampeao(res[0],isAdmin);renderTabelaRanking(res,semanas,isAdmin);
}

function renderCampeao(item,adminMode){
  var a=document.getElementById('campeaoArea');
  if(!item||item.media===0){a.innerHTML='';return;}
  var metaInfo=adminMode?' · Meta: '+R$(item.meta):'';
  a.innerHTML='<div class="campeao-card"><div class="star-bg">★</div><div class="campeao-trophy">🏆</div>'+
    '<div class="campeao-info"><div class="campeao-tag">🥇 Artilheiro do Mês — '+nomeMes(mesAtual)+'</div>'+
    '<div class="campeao-nome">'+item.rep.nome+'</div>'+
    '<div class="campeao-detalhe">Média de '+item.n+' semana'+(item.n!==1?'s':'')+metaInfo+'</div></div>'+
    '<div class="campeao-pct-box"><div class="campeao-pct-num">'+PCT(item.media)+'</div>'+
    '<div class="campeao-pct-lbl">da meta</div></div></div>';
}

function renderTabelaRanking(res,semanas,adminMode){
  var thSems=semanas.map(function(s){return '<th class="c" style="font-size:10px;line-height:1.5;">'+ddmm(s.inicio)+'<br><span style="opacity:.65">'+ddmm(s.fim)+'</span></th>';}).join('');
  var thMeta=adminMode?'<th class="r">Meta</th>':'';
  var html='<table><thead><tr><th style="width:44px">#</th><th>Representante</th>'+thMeta+thSems+'<th class="c">Média</th><th>Progresso</th></tr></thead><tbody>';
  res.forEach(function(item,idx){
    var pos=idx+1,pc=pos===1?'pos-1':pos===2?'pos-2':pos===3?'pos-3':'pos-n';
    var sems=item.pcts.map(function(s){
      if(!s.tem)return '<td class="c" style="color:var(--muted)">—</td>';
      var cor=s.p>=100?'var(--green)':s.p>=80?'var(--azul2)':s.p>=60?'var(--amber)':'var(--muted)';
      return '<td class="c"><span class="pct-val" style="color:'+cor+'">'+PCT(s.p)+'</span></td>';
    }).join('');
    var mCor=item.media>=100?'var(--green)':item.media>=80?'var(--azul2)':'var(--amber)';
    var bCor=idx===0?'bar-ouro':idx<3?'bar-laranja':'bar-azul';
    var tdMeta=adminMode?'<td class="r" style="font-size:13px;color:var(--muted);">'+(item.meta>0?R$(item.meta):'—')+'</td>':'';
    html+='<tr'+(pos===1?' class="top1"':'')+'><td><span class="pos-badge '+pc+'">'+pos+'</span></td>'+
      '<td><span class="rep-nome">'+item.rep.nome+'</span>'+(pos===1?' 🏆':'')+'</td>'+
      tdMeta+sems+'<td class="c"><span class="pct-media" style="color:'+mCor+'">'+PCT(item.media)+'</span></td>'+
      '<td style="min-width:110px"><div class="bar-wrap"><div class="bar-fill '+bCor+'" style="width:'+Math.min(item.media,100).toFixed(1)+'%"></div></div>'+
      '<div style="font-size:11px;color:var(--muted);margin-top:2px;">'+PCT(item.media)+'</div></td></tr>';
  });
  html+='</tbody></table>';
  document.getElementById('rankingTabela').innerHTML=html;
}

// ── MINHAS VENDAS ─────────────────────────────
function carregarMinhasVendas(){
  var mes=document.getElementById('mesMinhasVendas').value;
  var cont=document.getElementById('minhasVendasConteudo');
  cont.innerHTML='<div style="text-align:center;padding:60px;color:var(--muted)"><div class="spinner" style="margin:0 auto 12px"></div>Carregando...</div>';
  var repAtual=null;
  representantes.forEach(function(r){if(r.email===userAtual.email)repAtual=r;});
  if(!repAtual&&isAdmin){
    cont.innerHTML='<div class="empty-state"><div class="empty-icon">👑</div><div class="empty-title">Você é administrador</div><p style="font-size:14px;color:var(--muted)">Use <strong>Lançar Vendas</strong> para ver as planilhas.</p></div>';return;
  }
  if(!repAtual){
    cont.innerHTML='<div class="empty-state"><div class="empty-icon">🔍</div><div class="empty-title">Representante não encontrado</div><p style="font-size:14px;color:var(--muted)">Fale com o administrador.</p></div>';return;
  }
  Promise.all([db.collection('periodos').doc(mes).get(),db.collection('vendas').doc(mes).get()])
    .then(function(r){
      var periodo=r[0].exists?r[0].data():null;
      var vendas=r[1].exists?r[1].data():{};
      var metas=periodo?periodo.metas||{}:{};
      var semanas=periodo?periodo.semanas||[]:[];
      var meta=parseFloat(metas[repAtual.id]||0);
      var nDias=diasDoMes(mes),partes=mes.split('-'),ano=parseInt(partes[0]),mesNum=parseInt(partes[1]);
      var diaSem={};
      semanas.forEach(function(sem,idx){
        if(!sem.inicio||!sem.fim)return;
        var ini=new Date(sem.inicio+'T00:00:00'),fim=new Date(sem.fim+'T00:00:00');
        for(var d=1;d<=nDias;d++){var dt=new Date(ano,mesNum-1,d);if(dt>=ini&&dt<=fim)diaSem[d]=idx+1;}
      });
      var blocos=[];
      semanas.forEach(function(sem,idx){
        var dias=[];for(var d=1;d<=nDias;d++){if(diaSem[d]===idx+1)dias.push(d);}
        if(dias.length>0)blocos.push({key:'sem'+(idx+1),titulo:'Semana '+(idx+1)+' — '+ddmm(sem.inicio)+' a '+ddmm(sem.fim),dias:dias});
      });
      var diasFora=[];for(var d=1;d<=nDias;d++){if(!diaSem[d])diasFora.push(d);}
      if(diasFora.length>0)blocos.push({key:'fora',titulo:'Dias fora do período',dias:diasFora});
      var totalReal=0;
      for(var d=1;d<=nDias;d++){var dk=ano+'-'+pad(mesNum)+'-'+pad(d);totalReal+=parseFloat((vendas[dk]&&vendas[dk][repAtual.id])||0);}
      var pctReal=meta>0?(totalReal/meta)*100:0;
      var faltaReal=Math.max(0,meta-totalReal);
      var corPct=pctReal>=100?'verde':pctReal>=80?'':'laranja';
      var html='<div style="display:flex;align-items:center;gap:16px;margin-bottom:22px;">';
      html+='<div style="width:52px;height:52px;border-radius:50%;background:var(--azul-bg);color:var(--azul);font-size:18px;font-weight:800;display:flex;align-items:center;justify-content:center;">'+iniciais(repAtual.nome)+'</div>';
      html+='<div><div style="font-size:22px;font-weight:800;color:var(--azul);">'+repAtual.nome+'</div>';
      html+='<div style="font-size:13px;color:var(--muted)">'+nomeMes(mes)+'</div></div></div>';
      html+='<div class="stats-row">';
      html+='<div class="stat-card"><div class="stat-lbl">Meta Mensal</div><div class="stat-val">'+R$(meta)+'</div></div>';
      html+='<div class="stat-card"><div class="stat-lbl">Total Vendido</div><div class="stat-val '+corPct+'">'+R$(totalReal)+'</div></div>';
      html+='<div class="stat-card"><div class="stat-lbl">% Atingido</div><div class="stat-val '+corPct+'">'+PCT(pctReal)+'</div></div>';
      html+='<div class="stat-card"><div class="stat-lbl">Falta para Meta</div><div class="stat-val '+(faltaReal===0?'verde':'vermelho')+'">'+R$(faltaReal)+'</div></div>';
      html+='</div>';
      blocos.forEach(function(bloco){
        var subTotal=0;
        bloco.dias.forEach(function(d){var dk=ano+'-'+pad(mesNum)+'-'+pad(d);subTotal+=parseFloat((vendas[dk]&&vendas[dk][repAtual.id])||0);});
        var subPct=meta>0?(subTotal/meta)*100:0;
        html+='<div style="background:#0a1628;border:1px solid rgba(212,160,23,0.2);border-radius:16px;margin-bottom:18px;overflow:hidden;">';
        html+='<div style="background:var(--azul);padding:13px 20px;display:flex;align-items:center;justify-content:space-between;">';
        html+='<span style="font-family:Bebas Neue,cursive;font-size:15px;letter-spacing:1px;color:#fff;">'+bloco.titulo+'</span>';
        html+='<span style="font-size:13px;color:rgba(255,255,255,.75);">Subtotal: <strong style="color:#fff;">'+R$(subTotal)+'</strong> &nbsp;·&nbsp; <span style="color:var(--ouro2);">'+PCT(subPct)+'</span></span>';
        html+='</div><div style="overflow-x:auto;"><table style="border-collapse:collapse;width:100%;">';
        html+='<thead><tr><th style="padding:10px 14px;font-size:11px;font-weight:600;letter-spacing:1px;text-transform:uppercase;color:rgba(212,160,23,.7);background:rgba(0,0,0,0.2);border-bottom:1px solid rgba(212,160,23,.15);text-align:left;min-width:90px;">Info</th>';
        bloco.dias.forEach(function(d){
          var ds=diaSemNome(ano,mesNum,d);var fds=ds==='Dom'||ds==='Sáb';
          html+='<th style="padding:10px 10px;font-size:11px;font-weight:600;text-align:center;background:rgba(0,0,0,0.2);border-bottom:1px solid rgba(212,160,23,.15);min-width:85px;'+(fds?'opacity:.45;':'')+'">'+pad(d)+'/'+pad(mesNum)+'<br><span style="font-weight:400;font-size:10px;opacity:.7;">'+ds+'</span></th>';
        });
        html+='<th style="padding:10px 14px;font-size:11px;font-weight:700;text-align:center;background:var(--azul);color:#fff;min-width:100px;">Total</th></tr></thead>';
        html+='<tbody><tr><td style="padding:11px 14px;font-weight:600;font-size:13px;color:#fff;border-bottom:1px solid rgba(255,255,255,.07);">Venda (R$)</td>';
        var linTotal=0;
        bloco.dias.forEach(function(d){
          var dk=ano+'-'+pad(mesNum)+'-'+pad(d);
          var val=parseFloat((vendas[dk]&&vendas[dk][repAtual.id])||0);
          linTotal+=val;
          var ds=diaSemNome(ano,mesNum,d);var fds=ds==='Dom'||ds==='Sáb';
          html+='<td style="padding:11px 8px;text-align:center;border-bottom:1px solid rgba(255,255,255,.05);font-size:14px;font-weight:'+(val>0?'600':'400')+';color:'+(val>0?'var(--azul2)':'rgba(255,255,255,.3)')+';'+(fds?'opacity:.5;':'')+'">'+
            (val>0?R$(val):'—')+'</td>';
        });
        html+='<td style="padding:11px 10px;text-align:center;background:rgba(0,0,0,.2);font-weight:700;font-size:14px;border-bottom:1px solid rgba(255,255,255,.07);">'+R$(linTotal)+'</td></tr>';
        html+='<tr><td style="padding:8px 14px;font-size:12px;color:rgba(255,255,255,.5);">% do dia</td>';
        bloco.dias.forEach(function(d){
          var dk=ano+'-'+pad(mesNum)+'-'+pad(d);
          var val=parseFloat((vendas[dk]&&vendas[dk][repAtual.id])||0);
          var p1=meta>0?(val/meta)*100:0;var cor=p1>=10?'var(--green)':p1>0?'var(--azul2)':'var(--muted)';
          html+='<td style="padding:7px 6px;text-align:center;font-size:12px;color:'+cor+';">'+(p1>0?PCT(p1):'—')+'</td>';
        });
        html+='<td style="padding:8px 10px;text-align:center;background:rgba(0,0,0,.2);font-size:13px;font-weight:700;color:var(--azul2);">'+PCT(subPct)+'</td></tr>';
        html+='</tbody></table></div></div>';
      });
      if(!blocos.length){html+='<div class="empty-state"><div class="empty-icon">📅</div><div class="empty-title">Período não configurado</div></div>';}
      cont.innerHTML=html;
    });
}

// ── VENDAS GRID ───────────────────────────────
var dadosVendas=null;
function sincVendas(){
  var mes=document.getElementById('mesVendas').value;
  dadosVendas=null;
  Promise.all([db.collection('periodos').doc(mes).get(),db.collection('vendas').doc(mes).get()])
    .then(function(r){
      var vendasRaw=r[1].exists?r[1].data():{};
      var vendasFiltradas={};var prefixo=mes+'-';
      Object.keys(vendasRaw).forEach(function(k){if(k.indexOf(prefixo)===0)vendasFiltradas[k]=vendasRaw[k];});
      dadosVendas={periodo:r[0].exists?r[0].data():null,vendas:vendasFiltradas};
      renderRepsGrid(mes);
    });
}
function carregarDadosVendas(){sincVendas();}

function renderRepsGrid(mes){
  var cont=document.getElementById('repsGrid');
  var metas=dadosVendas&&dadosVendas.periodo?dadosVendas.periodo.metas||{}:{};
  var vendas=dadosVendas&&dadosVendas.vendas?dadosVendas.vendas:{};
  var nDias=diasDoMes(mes),partes=mes.split('-'),ano=parseInt(partes[0]),mesNum=parseInt(partes[1]);
  cont.innerHTML='';
  representantes.forEach(function(rep){
    var meta=parseFloat(metas[rep.id]||0),total=0;
    for(var d=1;d<=nDias;d++){var dk=ano+'-'+pad(mesNum)+'-'+pad(d);total+=parseFloat((vendas[dk]&&vendas[dk][rep.id])||0);}
    var percentual=meta>0?(total/meta)*100:0;
    var cor=percentual>=100?'var(--green)':percentual>=80?'var(--azul2)':percentual>=50?'var(--laranja)':'var(--muted)';
    var div=document.createElement('div');div.className='rep-card-btn';
    div.innerHTML='<div class="rep-card-pct" style="color:'+cor+'">'+PCT(percentual)+'</div>'+
      '<div class="rep-avatar">'+iniciais(rep.nome)+'</div>'+
      '<div class="rep-card-nome">'+rep.nome+'</div>'+
      '<div class="rep-card-meta">'+(meta>0?R$(meta):'Sem meta')+'</div>';
    (function(r,m){div.onclick=function(){abrirPlanilha(r,m);};})(rep,mes);
    cont.appendChild(div);
  });
}

// ── PLANILHA ADMIN ────────────────────────────
function abrirPlanilha(rep,mes){
  document.getElementById('vendas-lista').style.display='none';
  var planDiv=document.getElementById('vendas-planilha');
  planDiv.style.display='block';
  planDiv.innerHTML='<div style="text-align:center;padding:60px;color:var(--muted);"><div class="spinner" style="margin:0 auto 12px;"></div>Carregando...</div>';
  Promise.all([db.collection('periodos').doc(mes).get(),db.collection('vendas').doc(mes).get()])
    .then(function(r){
      var periodo=r[0].exists?r[0].data():null;
      var vendas=r[1].exists?r[1].data():{};
      var metas=periodo?periodo.metas||{}:{};
      var semanas=periodo?periodo.semanas||[]:[];
      var meta=parseFloat(metas[rep.id]||0);
      var nDias=diasDoMes(mes),partes=mes.split('-'),ano=parseInt(partes[0]),mesNum=parseInt(partes[1]);
      var diaSem={};
      semanas.forEach(function(sem,idx){
        if(!sem.inicio||!sem.fim)return;
        var ini=new Date(sem.inicio+'T00:00:00'),fim=new Date(sem.fim+'T00:00:00');
        for(var d=1;d<=nDias;d++){var dt=new Date(ano,mesNum-1,d);if(dt>=ini&&dt<=fim)diaSem[d]=idx+1;}
      });
      var blocos=[];
      semanas.forEach(function(sem,idx){
        var dias=[];for(var d=1;d<=nDias;d++){if(diaSem[d]===idx+1)dias.push(d);}
        if(dias.length>0)blocos.push({key:'sem'+(idx+1),titulo:'Semana '+(idx+1)+' — '+ddmm(sem.inicio)+' a '+ddmm(sem.fim),dias:dias});
      });
      var diasFora=[];for(var d=1;d<=nDias;d++){if(!diaSem[d])diasFora.push(d);}
      if(diasFora.length>0)blocos.push({key:'fora',titulo:'Dias fora do período configurado',dias:diasFora});
      var totalReal=0;
      for(var d=1;d<=nDias;d++){var dk=ano+'-'+pad(mesNum)+'-'+pad(d);totalReal+=parseFloat((vendas[dk]&&vendas[dk][rep.id])||0);}
      var pctReal=meta>0?(totalReal/meta)*100:0;
      var faltaReal=Math.max(0,meta-totalReal);
      var corPct=pctReal>=100?'verde':pctReal>=80?'':'laranja';
      var html='<div class="planilha-header">'+
        '<button class="btn-voltar" onclick="fecharPlanilha()">← Voltar</button>'+
        '<div class="planilha-info"><div class="planilha-nome">'+rep.nome+'</div><div class="planilha-sub">'+nomeMes(mes)+'</div></div>'+
        '<button class="btn-salvar btn-verde" style="margin-top:0;" onclick="salvarPlanilha(\''+rep.id+'\',\''+mes+'\','+nDias+','+mesNum+','+ano+')">💾 Salvar Planilha</button>'+
      '</div>';
      html+='<div class="stats-row">'+
        '<div class="stat-card"><div class="stat-lbl">Meta Mensal</div><div class="stat-val">'+R$(meta)+'</div></div>'+
        '<div class="stat-card"><div class="stat-lbl">Total Vendido</div><div class="stat-val '+corPct+'" id="statTotal">'+R$(totalReal)+'</div></div>'+
        '<div class="stat-card"><div class="stat-lbl">% Atingido</div><div class="stat-val '+corPct+'" id="statPct">'+PCT(pctReal)+'</div></div>'+
        '<div class="stat-card"><div class="stat-lbl">Falta para Meta</div><div class="stat-val '+(faltaReal===0?'verde':'vermelho')+'" id="statFalta">'+R$(faltaReal)+'</div></div>'+
      '</div>';
      blocos.forEach(function(bloco){
        var subTotal=0;
        bloco.dias.forEach(function(d){var dk=ano+'-'+pad(mesNum)+'-'+pad(d);subTotal+=parseFloat((vendas[dk]&&vendas[dk][rep.id])||0);});
        var subPct=meta>0?(subTotal/meta)*100:0;
        html+='<div style="background:#0a1628;border:1px solid rgba(212,160,23,0.2);border-radius:16px;margin-bottom:18px;overflow:hidden;">';
        html+='<div style="background:var(--azul);padding:13px 20px;display:flex;align-items:center;justify-content:space-between;">';
        html+='<span style="font-family:Bebas Neue,cursive;font-size:15px;letter-spacing:1px;color:#fff;">'+bloco.titulo+'</span>';
        html+='<span style="font-size:13px;color:rgba(255,255,255,.75);">Subtotal: <strong style="color:#fff;" id="totalSem_'+bloco.key+'">'+R$(subTotal)+'</strong> &nbsp;·&nbsp; <span id="pctSem_'+bloco.key+'" style="color:var(--ouro2);">'+PCT(subPct)+'</span></span>';
        html+='</div><div style="overflow-x:auto;"><table style="border-collapse:collapse;width:100%;">';
        html+='<thead><tr><th style="padding:10px 14px;font-size:11px;font-weight:600;letter-spacing:1px;text-transform:uppercase;color:rgba(212,160,23,.7);background:rgba(0,0,0,0.2);border-bottom:1px solid rgba(212,160,23,.15);text-align:left;min-width:90px;">Info</th>';
        bloco.dias.forEach(function(d){
          var ds=diaSemNome(ano,mesNum,d);var fds=ds==='Dom'||ds==='Sáb';
          html+='<th style="padding:10px 10px;font-size:11px;font-weight:600;text-align:center;background:rgba(0,0,0,0.2);border-bottom:1px solid rgba(212,160,23,.15);min-width:90px;'+(fds?'opacity:.45;':'')+'">'+pad(d)+'/'+pad(mesNum)+'<br><span style="font-weight:400;font-size:10px;opacity:.7;">'+ds+'</span></th>';
        });
        html+='<th style="padding:10px 14px;font-size:11px;font-weight:700;text-align:center;background:var(--azul);color:#fff;min-width:100px;">Total</th></tr></thead><tbody>';
        html+='<tr><td style="padding:9px 14px;font-weight:600;font-size:13px;color:#fff;border-bottom:1px solid rgba(255,255,255,.07);">Venda (R$)</td>';
        var linTot=0;
        bloco.dias.forEach(function(d){
          var dk=ano+'-'+pad(mesNum)+'-'+pad(d);
          var val=parseFloat((vendas[dk]&&vendas[dk][rep.id])||0);
          linTot+=val;
          html+='<td style="padding:5px 4px;text-align:center;border-bottom:1px solid rgba(255,255,255,.05);">'+
            '<input type="text" id="dia_'+d+'" inputmode="numeric" placeholder="0,00" '+
            'style="width:82px;padding:6px 7px;border:1.5px solid rgba(212,160,23,0.25);border-radius:8px;font-size:13px;text-align:right;outline:none;background:#0d1f50;color:#fff;" '+
            'oninput="formatarContabil(this);recalcPlanilha(\''+rep.id+'\','+meta+','+nDias+','+mesNum+','+ano+',\''+bloco.key+'\')" '+
            'onblur="finalizarContabil(this);recalcPlanilha(\''+rep.id+'\','+meta+','+nDias+','+mesNum+','+ano+',\''+bloco.key+'\')" '+
            'onfocus="this.select()"></td>';
        });
        html+='<td style="padding:9px 10px;text-align:center;background:rgba(0,0,0,.2);font-weight:700;font-size:14px;border-bottom:1px solid rgba(255,255,255,.07);" id="totalLinSem_'+bloco.key+'">'+R$(linTot)+'</td></tr>';
        html+='<tr><td style="padding:8px 14px;font-size:12px;color:rgba(255,255,255,.5);">% do dia</td>';
        bloco.dias.forEach(function(d){
          var dk=ano+'-'+pad(mesNum)+'-'+pad(d);
          var val=parseFloat((vendas[dk]&&vendas[dk][rep.id])||0);
          var p1=meta>0?(val/meta)*100:0;var cor=p1>=10?'var(--green)':p1>0?'var(--azul2)':'var(--muted)';
          html+='<td id="pctdia_'+d+'" style="padding:7px 6px;text-align:center;font-size:12px;color:'+cor+';">'+(p1>0?PCT(p1):'—')+'</td>';
        });
        html+='<td id="pctLinSem_'+bloco.key+'" style="padding:8px 10px;text-align:center;background:rgba(0,0,0,.2);font-size:13px;font-weight:700;color:var(--azul2);">'+PCT(subPct)+'</td></tr>';
        html+='</tbody></table></div></div>';
      });
      planDiv.innerHTML=html;
      // Inicializa inputs com valores existentes
      for(var d=1;d<=nDias;d++){
        var inp=document.getElementById('dia_'+d);
        if(inp){
          var dk2=ano+'-'+pad(mesNum)+'-'+pad(d);
          var val2=parseFloat((vendas[dk2]&&vendas[dk2][rep.id])||0);
          initContabil(inp,val2);
        }
      }
    });
}

function recalcPlanilha(repId,meta,nDias,mesNum,ano,chaveBloco){
  var total=0;
  for(var d=1;d<=nDias;d++){
    var inp=document.getElementById('dia_'+d);var v=inp?valorContabil(inp):0;total+=v;
    if(inp){inp.style.borderColor=v>0?'rgba(212,160,23,0.6)':'rgba(212,160,23,0.2)';}
    var pEl=document.getElementById('pctdia_'+d);
    if(pEl){var p1=meta>0?(v/meta)*100:0;var cor=p1>=10?'var(--green)':p1>0?'var(--azul2)':'var(--muted)';pEl.textContent=p1>0?PCT(p1):'—';pEl.style.color=cor;}
  }
  var pTotal=meta>0?(total/meta)*100:0,falta=Math.max(0,meta-total);
  var el=document.getElementById('statTotal');if(el)el.textContent=R$(total);
  var el2=document.getElementById('statPct');if(el2){el2.textContent=PCT(pTotal);el2.className='stat-val '+(pTotal>=100?'verde':pTotal>=80?'':'laranja');}
  var el3=document.getElementById('statFalta');if(el3){el3.textContent=R$(falta);el3.className='stat-val '+(falta===0?'verde':'vermelho');}
  document.querySelectorAll('[id^="totalSem_"]').forEach(function(elSem){
    var key=elSem.id.replace('totalSem_','');
    var linEl=document.getElementById('totalLinSem_'+key);if(!linEl)return;
    var tbl=linEl.closest('table');if(!tbl)return;
    var sub=0;tbl.querySelectorAll('input[id^="dia_"]').forEach(function(i){sub+=valorContabil(i);});
    elSem.textContent=R$(sub);
    if(linEl)linEl.textContent=R$(sub);
    var pEl=document.getElementById('pctSem_'+key);if(pEl){var sp=meta>0?(sub/meta)*100:0;pEl.textContent=PCT(sp);}
    var pEl2=document.getElementById('pctLinSem_'+key);if(pEl2){var sp2=meta>0?(sub/meta)*100:0;pEl2.textContent=PCT(sp2);}
  });
}

function salvarPlanilha(repId,mes,nDias,mesNum,ano){
  var mesSel=document.getElementById('mesVendas')?document.getElementById('mesVendas').value:mes;
  if(mesSel!==mes){toast('Erro: mês inconsistente. Recarregue.','erro');return;}
  db.collection('periodos').doc(mes).get().then(function(doc){
    var semanas=doc.exists?(doc.data().semanas||[]):[];
    var diaSem={};
    semanas.forEach(function(sem,idx){
      if(!sem.inicio||!sem.fim)return;
      var ini=new Date(sem.inicio+'T00:00:00'),fim=new Date(sem.fim+'T00:00:00');
      for(var d=1;d<=nDias;d++){var dt=new Date(parseInt(ano),parseInt(mesNum)-1,d);if(dt>=ini&&dt<=fim)diaSem[d]=idx+1;}
    });
    var promises=[];
    for(var d=1;d<=nDias;d++){
      var inp=document.getElementById('dia_'+d);
      var val=inp?valorContabil(inp):0;
      var dk=ano+'-'+pad(mesNum)+'-'+pad(d);
      if(val>0){
        var u={};var campo={};campo[repId]=val;if(diaSem[d])campo.semana=diaSem[d];u[dk]=campo;
        promises.push(db.collection('vendas').doc(mes).set(u,{merge:true}));
      }else{
        var u2={};u2[dk+'.'+repId]=firebase.firestore.FieldValue.delete();
        promises.push(db.collection('vendas').doc(mes).update(u2).catch(function(){}));
      }
    }
    return Promise.all(promises);
  }).then(function(){toast('Planilha salva! ✓','sucesso');dadosMes=null;})
  .catch(function(e){console.error(e);toast('Erro ao salvar.','erro');});
}

function fecharPlanilha(){
  document.getElementById('vendas-planilha').style.display='none';
  document.getElementById('vendas-lista').style.display='block';
  sincVendas();
}

// ── METAS ─────────────────────────────────────
function carregarMetasForm(){
  var mes=document.getElementById('mesMestasSelect').value;
  document.getElementById('mesMetas').textContent=nomeMes(mes);
  db.collection('periodos').doc(mes).get().then(function(doc){
    var metas=doc.exists?(doc.data().metas||{}):{};
    var grid=document.getElementById('metasGrid');grid.innerHTML='';
    representantes.forEach(function(rep){
      var div=document.createElement('div');div.className='form-field';
      div.innerHTML='<label>'+rep.nome+'</label><input type="text" id="meta_'+rep.id+'" placeholder="0,00" inputmode="numeric">';
      grid.appendChild(div);
      var inp=document.getElementById('meta_'+rep.id);
      initContabil(inp,metas[rep.id]||0);
      inp.addEventListener('input',function(){formatarContabil(this);});
      inp.addEventListener('blur',function(){finalizarContabil(this);});
    });
  });
}
function salvarMetas(){
  var mes=document.getElementById('mesMestasSelect').value;
  var metas={};
  representantes.forEach(function(rep){var v=document.getElementById('meta_'+rep.id);metas[rep.id]=v?valorContabil(v):0;});
  db.collection('periodos').doc(mes).set({metas:metas},{merge:true})
    .then(function(){toast('Metas de '+nomeMes(mes)+' salvas! ✓','sucesso');dadosMes=null;})
    .catch(function(){toast('Erro ao salvar metas.','erro');});
}

// ── PERÍODO ───────────────────────────────────
var semanasTemp=[{inicio:'',fim:''}];
function carregarPeriodoForm(){
  var mes=document.getElementById('cfgMes').value;
  db.collection('periodos').doc(mes).get().then(function(doc){
    if(doc.exists&&doc.data().semanas)semanasTemp=doc.data().semanas.map(function(s){return{inicio:s.inicio||'',fim:s.fim||''};});
    else semanasTemp=[{inicio:'',fim:''}];
    renderSemanasConfig();
  });
}
function renderSemanasConfig(){
  var c=document.getElementById('semanasConfig');if(!c)return;c.innerHTML='';
  semanasTemp.forEach(function(sem,idx){
    var d=document.createElement('div');d.className='semana-row';
    d.innerHTML='<label>Semana '+(idx+1)+'</label>'+
      '<span style="font-size:12px;color:var(--muted)">de</span>'+
      '<input type="date" value="'+(sem.inicio||'')+'" onchange="semanasTemp['+idx+'].inicio=this.value">'+
      '<span style="font-size:12px;color:var(--muted)">até</span>'+
      '<input type="date" value="'+(sem.fim||'')+'" onchange="semanasTemp['+idx+'].fim=this.value">'+
      (semanasTemp.length>1?'<button class="btn-rem" onclick="removeSemana('+idx+')">✕</button>':'');
    c.appendChild(d);
  });
}
function addSemana(){if(semanasTemp.length>=5){toast('Máximo 5 semanas.','erro');return;}semanasTemp.push({inicio:'',fim:''});renderSemanasConfig();}
function removeSemana(idx){semanasTemp.splice(idx,1);renderSemanasConfig();}
function salvarPeriodo(){
  var mes=document.getElementById('cfgMes').value;
  if(!semanasTemp.filter(function(s){return s.inicio&&s.fim;}).length){toast('Configure ao menos 1 semana.','erro');return;}
  db.collection('periodos').doc(mes).set({mes:mes,semanas:semanasTemp,atualizadoEm:firebase.firestore.FieldValue.serverTimestamp()},{merge:true})
    .then(function(){toast('Período de '+nomeMes(mes)+' salvo! ✓','sucesso');popularTodosSelects();dadosMes=null;})
    .catch(function(e){console.error(e);toast('Erro ao salvar período.','erro');});
}

// ── REPRESENTANTES ────────────────────────────
function renderRepsLista(){
  var c=document.getElementById('repsLista');if(!c)return;c.innerHTML='';
  representantes.forEach(function(rep,idx){
    var div=document.createElement('div');div.className='rep-list-row';
    div.innerHTML='<input type="text" value="'+(rep.nome||'')+'" placeholder="Nome" style="flex:2" oninput="representantes['+idx+'].nome=this.value">'+
      '<input type="email" value="'+(rep.email||'')+'" placeholder="E-mail" style="flex:3" oninput="representantes['+idx+'].email=this.value">'+
      (representantes.length>1?'<button class="btn-rem" onclick="remRep('+idx+')">✕</button>':'');
    c.appendChild(div);
  });
}
function addRep(){representantes.push({id:'rep'+Date.now(),nome:'',email:''});renderRepsLista();}
function remRep(idx){representantes.splice(idx,1);renderRepsLista();}
function salvarReps(){
  db.collection('config').doc('representantes').set({lista:representantes})
    .then(function(){toast('Representantes salvos! ✓','sucesso');})
    .catch(function(){toast('Erro ao salvar.','erro');});
}

// ── TOAST / SAIR ──────────────────────────────
var toastTimer;
function toast(msg,tipo){
  var el=document.getElementById('toast');
  el.textContent=msg;el.className='toast show '+(tipo||'');
  clearTimeout(toastTimer);toastTimer=setTimeout(function(){el.classList.remove('show');},3500);
}
function sair(){auth.signOut().then(function(){location.href='index.html';});}
